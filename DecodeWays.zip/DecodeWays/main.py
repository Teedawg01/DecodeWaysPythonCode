# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

from DecodeWays import numDecode


def main():
    test_cases = [("12", 2), ("226", 3), ("06", 0)]

    for input_str, expect in test_cases:
        result = numDecode(input_str)
        print(f"Input: {input_str} ")
        print(f"Output: {result} ")
        print(f"Expected: {expect} ")
        print(f"Test: {'pass' if result == expect else 'failed'} ")
        print()


if __name__ == "__main__":
    main()
